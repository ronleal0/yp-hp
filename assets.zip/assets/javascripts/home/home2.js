// TechOps JavaScript for v4 homepage - top.
// This is a manifest file that'll be compiled into home2.js, which will include all the files
// listed below.
//
// WARNING: THE FIRST BLANK LINE MARKS THE END OF WHAT'S TO BE PROCESSED, ANY BLANK LINE SHOULD
// GO AFTER THE REQUIRES BELOW.
//
//= require jquery_1_8_3.min
//= require jquery.fancybox
//= require jquery.form
//

//Google Banner
var googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
(function() {
  var gads = document.createElement('script');
  gads.async = true;
  gads.type = 'text/javascript';
  var useSSL = 'https:' == document.location.protocol;
  gads.src = (useSSL ? 'https:' : 'http:') +
          '//www.googletagservices.com/tag/js/gpt.js';
  var node = document.getElementsByTagName('script')[0];
  node.parentNode.insertBefore(gads, node);
})();

googletag.cmd.push(function() {
  googletag.defineSlot('/9180372/EYP_Home_Bottom_728x90', [728, 90], 'div-gpt-ad-1368781081400-0').addService(googletag.pubads());
  googletag.pubads().enableSingleRequest();
  googletag.enableServices();
});

//fb variables
if (document.domain == "localhost"){
  var fbappID = "433387216759793";
  var domainURL = document.domain + ":4444";
}else if (document.domain == "ken-beta.yellow-pages.ph"){
  var fbappID = "433387216759793";
  var domainURL = document.domain;
}else{
  var fbappID = "148166465371080";
  var domainURL = document.domain;
}

//FB snippet
window.fbAsyncInit = function() {
  FB.init({
    appId      : fbappID, // App ID
    channelUrl : '//'+domainURL+'/', // Channel File
    status     : true, // check login status
    cookie     : true, // enable cookies to allow the server to access the session
    xfbml      : true  // parse XFBML
  });
  FB.Event.subscribe('auth.logout', function (response) {
      $('.login-link,.auth-user').html('<div style="margin-right:10px;"><img src="/assets/ac_indicator.gif"  style="margin-right:3px;" /> Logging out to Facebook...</div>');
      $.ajax({
          url: '/fb/logout',
          cache: false,
          success: function(data){
            //alert(data);
          }
        })
      window.location.href="http://" + domainURL + "/user/logout"
  });
  FB.Event.subscribe('auth.authResponseChange', function(response) {
    if (response.status === 'connected') {
      fbAPI();
    } else if (response.status === 'not_authorized') {
      $.ajax({
          url: '/fb/logout',
          cache: false,
          success: function(data){
            //alert(data);
          }
        })
      FB.login();
    } else {
      $.ajax({
          url: '/fb/logout',
          cache: false,
          success: function(data){
            //alert(data);
          }
        })
      FB.login();
    }
  });
  };
  (function(d){
   var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];
   if (d.getElementById(id)) {return;}
   js = d.createElement('script'); js.id = id; js.async = true;
   js.src = "//connect.facebook.net/en_US/all.js";
   ref.parentNode.insertBefore(js, ref);
  }(document));
  function fbAPI() {
    FB.api('/me', function(response) {
        $('.login-link,.signup-link').html('');
        $('.login-link').html('<div style="margin-right:10px;"><img src="/assets/ac_indicator.gif" style="margin-right:3px;" /> Connecting to Facebook...</div>');
        $.ajax({
          url: '/fb/create?email='+response.email+'&first_name='+response.first_name+'&last_name='+response.last_name+'&fb_id='+response.id,
          cache: false,
          success: function(data){            
            if (data){
              $('.login-link').html('<span class="auth-user"><strong><a id="bt-panel-trigger" class="biz-tools-link" href="">'+data+'</a></strong></span>');
            }else{
              $('.login-link').html('<span class="auth-user"><strong><a id="bt-panel-trigger" class="biz-tools-link" href="">'+data+'</a></strong></span>');
            }
            var login = $('#login_status').val();
            if (login != "login"){
              location.reload(true);
            } 
          }
        })
    });
  }

$(document).ready(function() {
  //Add more business

$('#post_create_new_business').live("click", function() {
      $(".img_loader").show();
      $("#post_create_new_business").hide();
      setTimeout(function () {
          $("#frm_create_new_business").submit();
      }, 2000);
});

$('.new-business').live("click", function() {
      $.fancybox(
          {
              'type': 'ajax',
              'href': '/business/new_business'
          });
  });

$('#post_create_claim_business').live("click", function() {
      $(".img_loader").show();
      $("#post_create_claim_business").hide();
      setTimeout(function () {
          $("#frm_claim_business").submit();
      }, 2000);
});

$('.claim-business').live("click", function() {
      var business_id = $('#business_id').val();
      var permalink = $('#permalink').val();
      if (business_id > 0){
        $.fancybox(
          {
              'type': 'ajax',
              'href': '/claim-business/index?business_id=' + business_id + '&permalink='+ permalink,
              helpers : {
                overlay : {closeClick: false}
              }
          });
      }else{
        $.fancybox(
          {
              'type': 'ajax',
              'href': '/claim-business/index',
              helpers : {
                overlay : {closeClick: false}
              }
          });
      }
  });

  $("a.fancybox").fancybox({
    closeClick: false,
    fitToView : true,
    padding: 8,
    openEffect : 'elastic',
    closeEffect : 'elastic',
    nextSpeed: 0, //important
    prevSpeed: 0, //important
    helpers : {
        overlay : {closeClick: false}
    }
  });


 $('#biz-province').live("change", function() {
        var province_id = $(this).val();
        if (province_id == 0) {
          var htmlStr = '\
          <select id="biz-city" class="biz-select" name="business[location_id]">\
          <option value="">- Choose a City -</option>\
          </select>\
          ';
          $("#biz-city").each(function(){
            $(this).html(htmlStr);
          });
          return false;
        }
        $.ajax({
            type: "GET",
            url: "/business/dynamic_city/" + province_id,
            success: function(item_results) {
                $('#biz-city').html('');
                $('#biz-city').html(item_results);
            }
        });
  });

//end
  //flexslider
  $('.flex-next, .flex-prev, .flex-control-paging').live('click',function(){
      $('.flexslider').flexslider("play");
  });


  //autocomplete
  $('input[name="what"]').autocomplete('/autocomplete_keyword', {
      cacheLength:0, 
      matchContains:0, 
      matchSubset:0, 
      minChars:1, 
      loadingClass: "autocomplete_indicator",
      selectOnly:false,
      selectFirst:false,
      onItemSelect: function(item) {
        $('input[name="what"]').focus();
      }
  })
  $('input[name="where"]').autocomplete('/location', {
      cacheLength:0, 
      matchContains:0, 
      matchSubset:0, 
      minChars:1, 
      loadingClass: "autocomplete_indicator",
      selectOnly:false,
      selectFirst:false,
      onItemSelect: function(item) {
        $('input[name="where"]').focus();
      }
  })
  if (navigator.geolocation)
  {
    navigator.geolocation.getCurrentPosition(showPosition);
  }else{
    $('#search-where-home-top').val("Metro Manila");
  }

})